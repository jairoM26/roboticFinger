#include <stdio.h>
#include <stdlib.h>
#include "../Library/roboticArmLib.h"

const char * deviceName = "/dev/ttyACM0";
char * configFile = "configFile.txt";
int resolution = 1;

/**
 * @brief 
 * 
 */
void interpreter();